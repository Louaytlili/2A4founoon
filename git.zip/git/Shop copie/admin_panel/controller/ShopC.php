<?php

require '../config.php';

class ShopC
{

    public function listShop()
    {
        $sql = "SELECT * FROM Shop";

        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function deleteShop($ide)
    {
        $sql = "DELETE FROM Shop WHERE nom = :nom";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':nom', $ide);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }


    function addShop($Shop)
    {
        $sql = "INSERT INTO Shop  
        VALUES (NULL, :nom,:artist, :description,:status,:type)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'nom' => $Shop->getnom(),
                'prix' => $Shop->getprix(),
                'artist' => $Shop->getartist(),
                'description' => $Shop->getdescription(),
                'status' => $Shop->getstatus(),
                'type' => $Shop->gettype(),
            ]);
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }


    function showShop($id)
    {
        $sql = "SELECT * from Shop where prixShop = $prix";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();
            $Shop = $query->fetch();
            return $Shop;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    function updateShop($Shop, $prix)
    {   
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE Shop SET 
                    nom = :nom, 
                    artist = :artist, 
                    description = :description, 
                    status = :status,
                    type = :type,
                WHERE prixShop= :prix'
            );
            
            $query->execute([
                'prix' => $prix,
                'nom' => $Shop->getnom(),
                'artist' => $Shop->getartist(),
                'description' => $Shop->getdescription(),
                'status' => $Shop->getstatus(),
                'type' => $Shop->gettype(),
            ]);
            
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }
}
