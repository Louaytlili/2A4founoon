<?php
// Importations bécessaires
include 'C:\xampp2\htdocs\Shop\controller2\CategorieC.php';
include 'C:\xampp2\htdocs\Shop\model2\Categorie.php';

// fichier de configuration de la base de données
require 'config.php';

// instanciation d'un nouvel objet PDO
$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// création de la requête SQL
$sql = "SELECT * FROM categories";

// préparation de la requête SQL
$stmt = $pdo->prepare($sql);

// exécution de la requête SQL
$stmt->execute();

// récupération des résultats de la requête
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
    </tr>
    <?php foreach ($categories as $category): ?>
        <tr>
            <td><?php echo $category['id']; ?></td>
            <td><?php echo $category['name']; ?></td>
        </tr>
    <?php endforeach; ?>
</table>