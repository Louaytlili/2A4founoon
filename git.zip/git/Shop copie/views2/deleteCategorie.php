<?php
include 'C:\xampp2\htdocs\Shop\controller2\CategorieC.php';

        // Code to delete the record goes here
        $CategorieC = new CategorieC();
        $CategorieC->deleteCategorie($_GET["id"]);
        header('Location:listCategorie.php');
?>