<?php

include 'C:\xampp2\htdocs\Shop\controller2\CategorieC.php';
include 'C:\xampp2\htdocs\Shop\model\Categorie.php';
$error = "";

// create client
$Categorie = null;
// create an instance of the controller
$CategorieC = new CategorieC();


if (
    isset($_POST["Visual"]) &&
    isset($_POST["Abstract"]) &&
    isset($_POST["Futurism"])
) {
    if (
        !empty($_POST['Visual']) &&
        !empty($_POST['Abstract']) &&
        !empty($_POST['Futurism'])
    ) {
        foreach ($_POST as $key => $value) {
            echo "Key: $key, Value: $value<br>";
        }
        $Categorie = new Categorie(
            null,
            $_POST['Visual'],
            $_POST['Abstract'],
            $_POST['Futurism']
        );
        var_dump($Categorie);
        
        $CategorieC->updateCategorie($Categorie, $_POST['idCategorie']);

        header('Location:listCategorie.php');
    } else
        $error = "Missing information";
}



?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>

<body>
    <button><a href="listCategorie.php">Back to list</a></button>
    <hr>

    <div id="error">
        <?php echo $error; ?>
    </div>

    <?php
    if (isset($_POST['idCategorie'])) {
        $Categorie = $CategorieC->showCategorie($_POST['idCategorie']);
        
    ?>

        <form action="" method="POST">
            <table>
            <tr>
                    <td><label for="nom">IdCategorie :</label></td>
                    <td>
                        <input type="text" id="idCategorie" name="idCategorie" value="<?php echo $_POST['idCategorie'] ?>" readonly />
                        <span id="erreurNom" style="color: red"></span>
                    </td>
                </tr>
                <tr>
                    <td><label for="Visual">Visual Art :</label></td>
                    <td>
                        <input type="text" id="Visual" name="Visual" value="<?php echo Categorie['Visual'] ?>" />
                        <span id="erreurVisual" style="color: red"></span>
                    </td>
                </tr>
                <tr>
                    <td><label for="Abstract">Abstract Art :</label></td>
                    <td>
                        <input type="text" id="Abstract" name="Abstract" value="<?php echo $Categorie['Abstract'] ?>" />
                        <span id="erreurAbstract" style="color: red"></span>
                    </td>
                </tr>
                <tr>
                    <td><label for="Futurism">Futurism Art :</label></td>
                    <td>
                        <input type="text" id="Futurism" name="Futurism" value="<?php echo $Categorie['Futurism'] ?>" />
                        <span id="erreurFuturism" style="color: red"></span>
                    </td>
                </tr>

                <td>
                    <input type="submit" value="Save">
                </td>
                <td>
                    <input type="reset" value="Reset">
                </td>
            </table>

        </form>
    <?php
    }
    ?>
</body>

</html>