<?php
include 'C:\xampp2\htdocs\Shop\controller2\CategorieC.php';

$c = new CategorieC();
$tab = $c->listCategorie();

?>

<center>
    <h1>List of Categorie</h1>
    <h2>
        <a href="addCategorie.php">Add Categorie</a>
    </h2>
</center>
<table border="1" align="center" width="70%">
    <tr>
        <th>idCategorie</th>
        <th>'Product Name</th>
        <th>Category Name</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>


    <?php
    foreach ($tab as $Categorie) {
    ?>

        <tr>
            <td><?= $Categorie['idCategorie']; ?></td>
            <td><?= $Categorie['Product Name']; ?></td>
            <td><?= $Categorie['Category Name']; ?></td>
            <td align="center">
                <form method="POST" action="updateCategorie.php">
                    <input type="submit" name="update" value="Update">
                    <input type="hidden" value=<?PHP echo $Categorie['idCategorie']; ?> name="idCategorie">
                </form>
            </td>
            <td>
                <a href="deleteCategorie.php?id=<?php echo $Categorie['idCategorie']; ?>">Delete</a>
            </td>
        </tr>
    <?php
    }
    ?>
</table>