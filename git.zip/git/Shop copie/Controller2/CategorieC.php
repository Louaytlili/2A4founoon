<?php

require 'C:\xampp2\htdocs\Shop\config.php';

class CategorieC
{

    public function listCategorie()
    {
        $sql = "SELECT * FROM Categorie";

        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function deleteCategorie($ide)
    {
        $sql = "DELETE FROM Shop WHERE idCategorie = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $ide);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }


    function addCategorie($Categorie)
    {
        $sql = "INSERT INTO Categorie (Visual, Abstract, Futurism) VALUES (NULL, :Visual,:Abstract, :Futurism)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'Visual' => $Categorie->getVisual(),
                'Abstract' => $Categorie->getAbstract(),
                'Futurism' => $Categorie->getFuturism(),
            ]);
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }


    function showCategorie($id)
    {
        $sql = "SELECT * from Categorie where idCategorie = $id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();
            $Categorie = $query->fetch();
            return $Categorie;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    function updateCategorie($Categorie, $id)
    {   
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE Categorie SET 
                    Visual = :Visual, 
                    Abstract = :Abstract, 
                    Futurism = :Futurism
                WHERE idCategorie= :id'
            );
            
            $query->execute([
                //'id' => $id,
                'Visual' => $Categorie->getVisual(),
                'Abstract' => $Categorie->getAbstract(),
                'Futurism' => $Categorie->getFuturism(),
            ]);
            
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }
}
