<?php
class Categorie
{
    private ?int $idCategorie = null;
    private ?string $Visual = null;
    private ?string $Abstract = null;
    private ?string $Futurism = null;
    public function __construct($id = null, $v, $a, $f)
    {
        $this->idCategorie = $id;
        $this->Visual = $v;
        $this->Abstract = $a;
        $this->Futurism = $f;
    }


    public function getIdCategorie()
    {
        return $this->idCategorie;
    }


    public function getVisual()
    {
        return $this->Visual;
    }


    public function setVisual($Visual)
    {
        $this->Visual = $Visual;

        return $this;
    }


    public function getAbstract()
    {
        return $this->Abstract;
    }


    public function setAbstract($Abstract)
    {
        $this->Abstract = $Abstract;

        return $this;
    }


    public function getFuturism()
    {
        return $this->Futurism;
    }


    public function setFuturism($Futurism)
    {
        $this->Futurism = $Futurism;

        return $this;
    }
}
